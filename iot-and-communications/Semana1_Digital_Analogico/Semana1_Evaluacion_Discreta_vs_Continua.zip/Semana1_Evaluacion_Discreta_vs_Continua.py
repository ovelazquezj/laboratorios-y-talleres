# Evaluación — Semana 1: Señales digitales (discretas) vs analógicas (continuas)
# Objetivo: modelar una señal continua, una señal discreta y su relación mínima.
# Importante: este archivo NO incluye soluciones, salvo los imports de la Sección 1.
# El alumno debe interpretar las fórmulas y seguir los algoritmos para escribir su propio código. # =========================
# Sección 1 — Librerías
# =========================
# Por qué:
# - NumPy: eje de tiempo y operaciones con arreglos numéricos.
# - Matplotlib: graficar cada señal en su propia figura.
# Reglas de ploteo: una señal por figura; no usar seaborn; no fijar colores; ejes rotulados; rejilla. import numpy as np
import matplotlib.pyplot as plt # (Opcional) Define aquí funciones auxiliares de gráfica si lo deseas.
# ------------------------------------------------------------------- # =====================================
# Sección 2 — Señal continua sinusoidal
# =====================================
# Fórmula 2.1 — Señal sinusoidal (función seno)
# Términos: amplitud, frecuencia, fase, componente DC (offset), frecuencia angular.
# Definiciones previas (parámetros y unidades):
# - Amplitud A (unidad de la señal)
# - Frecuencia f (Hz)
# - Fase inicial φ (rad)
# - Componente DC C (unidad de la señal)
# - Frecuencia angular ω ("omega es dos pi multiplicado por la frecuencia")
# Enunciado (natural):
# "El valor de la señal en el tiempo t es C más A multiplicado por el seno de ω multiplicado por t más φ."
# "El periodo T es uno dividido entre la frecuencia f."
#
# Algoritmo 2.A :
# 1) Define A, f, φ, C, duración total (s) y frecuencia de muestreo (Hz).
# 2) Define Delta t = 1 / frecuencia de muestreo.
# 3) Define el dominio temporal: instantes desde 0 hasta antes de la duración total, espaciados por Delta t.
# 4) Define ω = 2 * pi * f.
# 5) Evalúa la fórmula para cada instante del dominio.
# 6) Grafica la señal en una figura con título, ejes y rejilla.
#
# === ESPACIO DEL ALUMNO (Sección 2) ===
# Escribe tu código aquí para construir y graficar la señal sinusoidal.
# --------------------------------------------------------------- # =========================================
# Sección 3 — Señal discreta (tren de pulsos)
# =========================================
# Fórmula 3.1 — Tren periódico de pulsos (0/1 con ventana por período)
# Términos: tren de pulsos, período, ancho de pulso, ciclo de trabajo.
# Definiciones previas:
# - Período base (s)
# - Ancho del pulso (s)
# - Ciclo de trabajo = ancho del pulso / período
# Enunciado (natural):
# "La señal de pulsos toma el valor uno desde el inicio de cada período y durante una ventana de duración fija; el resto del período toma el valor cero."
# "El tiempo dentro del período es el resto de dividir el tiempo total entre el período base."
#
# Algoritmo 3.A :
# 1) Define período base y ancho del pulso (0 < ancho < período).
# 2) Define el dominio temporal (duración total y resolución) o reutiliza el de la Sección 2.
# 3) Para cada instante, determina el tiempo dentro del período (resto de dividir tiempo entre período).
# 4) Asigna 1 si está dentro de la ventana [inicio, inicio + ancho); en otro caso 0.
# 5) Grafica en su propia figura con zoom temporal para ver los pulsos.
#
# === ESPACIO DEL ALUMNO (Sección 3) ===
# Escribe tu código aquí para construir y graficar el tren de pulsos.
# --------------------------------------------------------------- # =====================================================
# Sección 4 — Simulación conjunta (tres señales) y relación
# =====================================================
# Fórmula 4.1 — Tics de referencia (reloj periódico)
# "La señal de tics toma el valor uno en una ventana corta al inicio de cada período de referencia, y cero el resto del tiempo."
# Parámetros: período de referencia (s) y ancho del tic (s).
#
# Fórmula 4.2 — Pulso de control con retardo proporcional al porcentaje continuo
# Términos: retardo, ventana desplazada, relación continua–discreta.
# "El retardo del pulso es igual a la parte no solicitada del período de referencia."
# "Es decir: retardo = (cien menos el porcentaje solicitado) / cien * período de referencia."
# "El pulso de control vale uno desde que termina el retardo y durante su ancho fijo; fuera de esa ventana vale cero."
# Nota: el porcentaje solicitado es la señal continua de la Sección 2.
#
# Algoritmo 4.A :
# 1) Define período de referencia y ancho del tic y construye los tics (tren periódico con ventana corta).
# 2) Asegura que tienes la señal continua (porcentaje) en el mismo dominio temporal.
# 3) Para cada instante: determina el tiempo dentro del período; calcula el retardo según el porcentaje; asigna 1 al pulso si cae en [retardo, retardo + ancho del pulso), si no 0.
# 4) Grafica en tres figuras separadas: continua (completa), tics (zoom), pulso de control (mismo zoom que tics).
# 5) Describe en una línea qué ocurre con el retardo cuando el porcentaje sube o baja.
#
# === ESPACIO DEL ALUMNO (Sección 4) ===
# Escribe tu código aquí para construir y graficar las tres señales.
# --------------------------------------------------------------- # -----------------------------
# Anexo — Rúbrica (resumen)
# -----------------------------
# Niveles: 4=Excelente, 3=Satisfactorio, 2=Básico, 1=Insuficiente
# 1) Preparación: imports, dominio temporal, figuras.
# 2) Continua: interpreta fórmula, sigue algoritmo, parámetros con unidades, gráfica clara.
# 3) Discreta: período y ancho definidos, pulsos regulares, zoom correcto.
# 4) Conjunta: tics + pulso con retardo proporcional; explicación de cómo cambia el retardo con el porcentaje.
# 5) Presentación: reglas de ploteo, comentarios, unidades.